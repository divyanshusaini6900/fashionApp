import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../core/services/firebase_service.dart';

// Events
abstract class AuthEvent extends Equatable {
  const AuthEvent();

  @override
  List<Object> get props => [];
}

class AuthLoginRequested extends AuthEvent {
  final String email;
  final String password;

  const AuthLoginRequested({
    required this.email,
    required this.password,
  });

  @override
  List<Object> get props => [email, password];
}

class AuthLogoutRequested extends AuthEvent {
  const AuthLogoutRequested();
}

class AuthStatusChanged extends AuthEvent {
  final User? user;

  const AuthStatusChanged({required this.user});

  @override
  List<Object> get props => [user ?? ''];
}

class AuthCheckRequested extends AuthEvent {
  const AuthCheckRequested();
}

class AuthPhoneVerificationRequested extends AuthEvent {
  final String phoneNumber;
  final bool isLogin;

  const AuthPhoneVerificationRequested({
    required this.phoneNumber,
    this.isLogin = true,
  });

  @override
  List<Object> get props => [phoneNumber, isLogin];
}

class AuthOtpVerificationRequested extends AuthEvent {
  final String verificationId;
  final String otpCode;
  final bool isSignUp;
  final String? fullName;
  final String? email;
  final String? phoneNumber;
  final String? city;

  const AuthOtpVerificationRequested({
    required this.verificationId,
    required this.otpCode,
    this.isSignUp = false,
    this.fullName,
    this.email,
    this.phoneNumber,
    this.city,
  });

  @override
  List<Object> get props => [verificationId, otpCode, isSignUp];
}

class AuthSignUpRequested extends AuthEvent {
  final String name;
  final String email;
  final String phoneNumber;
  final String city;

  const AuthSignUpRequested({
    required this.name,
    required this.email,
    required this.phoneNumber,
    required this.city,
  });

  @override
  List<Object> get props => [name, email, phoneNumber, city];
}

// Add this new state for storing signup data
class AuthSignUpDataStored extends AuthState {
  final String verificationId;
  final String phoneNumber;
  final String fullName;
  final String email;

  const AuthSignUpDataStored({
    required this.verificationId,
    required this.phoneNumber,
    required this.fullName,
    required this.email,
  });

  @override
  List<Object> get props => [verificationId, phoneNumber, fullName, email];
}

// States
abstract class AuthState extends Equatable {
  const AuthState();

  @override
  List<Object> get props => [];
}

class AuthInitial extends AuthState {
  const AuthInitial();
}

class AuthLoading extends AuthState {
  const AuthLoading();
}

class AuthAuthenticated extends AuthState {
  final User user;

  const AuthAuthenticated({required this.user});

  @override
  List<Object> get props => [user];
}

class AuthUnauthenticated extends AuthState {
  const AuthUnauthenticated();
}

class AuthError extends AuthState {
  final String message;

  const AuthError({required this.message});

  @override
  List<Object> get props => [message];
}

class AuthPhoneVerificationSent extends AuthState {
  final String verificationId;
  final String phoneNumber;
  final bool isSignUp;
  final String? fullName;
  final String? email;

  const AuthPhoneVerificationSent({
    required this.verificationId,
    required this.phoneNumber,
    this.isSignUp = false,
    this.fullName,
    this.email,
  });

  @override
  List<Object> get props => [verificationId, phoneNumber, isSignUp];
}

class AuthOtpVerified extends AuthState {
  final String verificationId;

  const AuthOtpVerified({required this.verificationId});

  @override
  List<Object> get props => [verificationId];
}

class AuthSignUpSuccess extends AuthState {
  final String message;

  const AuthSignUpSuccess({required this.message});

  @override
  List<Object> get props => [message];
}

// BLoC
class AuthBloc extends Bloc<AuthEvent, AuthState> {
  StreamSubscription<User?>? _authStateSubscription;
  
  AuthBloc() : super(const AuthInitial()) {
    on<AuthLoginRequested>(_onLoginRequested);
    on<AuthLogoutRequested>(_onLogoutRequested);
    on<AuthStatusChanged>(_onAuthStatusChanged);
    on<AuthCheckRequested>(_onAuthCheckRequested);
    on<AuthPhoneVerificationRequested>(_onPhoneVerificationRequested);
    on<AuthOtpVerificationRequested>(_onOtpVerificationRequested);
    on<AuthSignUpRequested>(_onSignUpRequested);
    
    // Initialize auth state listener
    _initializeAuthListener();
  }
  
  void _initializeAuthListener() {
    // Cancel any existing subscription
    _authStateSubscription?.cancel();
    
    // Listen to auth state changes with error handling
    _authStateSubscription = FirebaseService.authStateChanges.listen(
      (user) {
        // Add a small delay to ensure Firebase is fully initialized
        Future.delayed(const Duration(milliseconds: 100), () {
          add(AuthStatusChanged(user: user));
        });
      },
      onError: (error) {
        print('Auth state error: $error');
        // Handle PigeonUserDetails error specifically
        if (error.toString().contains('PigeonUserDetails')) {
          print('Ignoring PigeonUserDetails error');
          // Try to get current user directly
          Future.delayed(const Duration(milliseconds: 500), () {
            final user = FirebaseService.currentUser;
            add(AuthStatusChanged(user: user));
          });
        } else {
          add(const AuthStatusChanged(user: null));
        }
      },
    );
  }

  Future<void> _onAuthCheckRequested(
    AuthCheckRequested event,
    Emitter<AuthState> emit,
  ) async {
    try {
      final user = FirebaseService.currentUser;
      if (user != null) {
        emit(AuthAuthenticated(user: user));
      } else {
        emit(const AuthUnauthenticated());
      }
    } catch (e) {
      print('Error checking auth status: $e');
      emit(const AuthUnauthenticated());
    }
  }

  Future<void> _onLoginRequested(
    AuthLoginRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(const AuthLoading());

    try {
      // Add a small delay to ensure proper initialization
      await Future.delayed(const Duration(milliseconds: 300));
      
      UserCredential? credential;
      try {
        credential = await FirebaseService.signInWithEmailAndPassword(
          event.email,
          event.password,
        );
      } catch (authError) {
        // Handle auth-specific errors
        String errorMessage = authError.toString();
        
        // Check for PigeonUserDetails error
        if (errorMessage.contains('PigeonUserDetails')) {
          print('⚠️ PigeonUserDetails error detected, checking if login was successful...');
          
          // Wait a moment and check if user is logged in
          await Future.delayed(const Duration(milliseconds: 1000));
          
          final currentUser = FirebaseService.currentUser;
          if (currentUser != null && currentUser.email == event.email) {
            print('✅ User is logged in despite error');
            emit(AuthAuthenticated(user: currentUser));
            return;
          }
        }
        
        // If not a PigeonUserDetails error or login failed, show generic error
        emit(const AuthError(message: 'Login failed. Please check your credentials and try again.'));
        return;
      }

      // If credential is null but no error thrown (happens with PigeonUserDetails)
      if (credential == null) {
        // Check if user is actually logged in
        await Future.delayed(const Duration(milliseconds: 1000));
        final currentUser = FirebaseService.currentUser;
        
        if (currentUser != null) {
          emit(AuthAuthenticated(user: currentUser));
          return;
        }
      }

      if (credential?.user != null) {
        // Wait a bit for Firebase to fully update
        await Future.delayed(const Duration(milliseconds: 500));
        
        // Get current user with error handling
        User? currentUser;
        try {
          currentUser = FirebaseService.currentUser;
        } catch (e) {
          print('Warning: Error getting current user: $e');
          // Try to use the user from credential
          currentUser = credential!.user;
        }
        
        if (currentUser != null) {
          emit(AuthAuthenticated(user: currentUser));
        } else {
          emit(const AuthError(message: 'Login successful but user data not available. Please try again.'));
        }
      } else {
        emit(const AuthError(message: 'Login failed. Please check your credentials and try again.'));
      }
    } catch (e) {
      print('Login error: $e');
      
      // Handle PigeonUserDetails error
      if (e.toString().contains('PigeonUserDetails')) {
        // Wait and check if user is logged in
        await Future.delayed(const Duration(milliseconds: 1000));
        final user = FirebaseService.currentUser;
        if (user != null) {
          emit(AuthAuthenticated(user: user));
          return;
        }
      }
      
      // For all other errors, show generic message
      emit(const AuthError(message: 'An unexpected error occurred. Please try again.'));
    }
  }

  Future<void> _onLogoutRequested(
    AuthLogoutRequested event,
    Emitter<AuthState> emit,
  ) async {
    try {
      print('🚪 Processing logout request...');
      emit(const AuthLoading());

      // Sign out from Firebase
      await FirebaseService.signOut();
      print('✅ User signed out from Firebase');

              // Add a small delay to ensure Firebase has updated
        await Future.delayed(const Duration(milliseconds: 300));

        // Emit unauthenticated state
      emit(const AuthUnauthenticated());
      print('🔄 Auth state updated to unauthenticated');
      
    } catch (e) {
      print('❌ Logout error: $e');
      emit(AuthError(message: _getErrorMessage(e)));
    }
  }

  void _onAuthStatusChanged(
    AuthStatusChanged event,
    Emitter<AuthState> emit,
  ) {
    try {
      if (event.user != null) {
        emit(AuthAuthenticated(user: event.user!));
      } else {
        emit(const AuthUnauthenticated());
      }
    } catch (e) {
      print('Error in auth status changed: $e');
      if (e.toString().contains('PigeonUserDetails')) {
        print('Ignoring PigeonUserDetails error in auth status changed');
        // Try to emit current state without changes
        return;
      }
      emit(const AuthUnauthenticated());
    }
  }
  
  String _getErrorMessage(dynamic error) {
    if (error is FirebaseAuthException) {
      switch (error.code) {
        case 'user-not-found':
          return 'No user found with this email address.';
        case 'wrong-password':
          return 'Wrong password provided.';
        case 'invalid-email':
          return 'The email address is invalid.';
        case 'user-disabled':
          return 'This user account has been disabled.';
        case 'too-many-requests':
          return 'Too many login attempts. Please try again later.';
        case 'operation-not-allowed':
          return 'Email/password accounts are not enabled.';
        case 'network-request-failed':
          return 'Network error. Please check your connection.';
        default:
          return 'Authentication error: ${error.message}';
      }
    }
    
    // Handle PigeonUserDetails error
    if (error.toString().contains('PigeonUserDetails')) {
      return 'Login successful. Please wait...';
    }
    
    return 'An unexpected error occurred. Please try again.';
  }

  Future<void> _onPhoneVerificationRequested(
    AuthPhoneVerificationRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(const AuthLoading());

    try {
      // Format phone number to E.164 format
      String phoneNumber = event.phoneNumber;
      if (!phoneNumber.startsWith('+')) {
        // Assuming Indian numbers, add +91
        if (phoneNumber.startsWith('0')) {
          phoneNumber = '+91${phoneNumber.substring(1)}';
        } else {
          phoneNumber = '+91$phoneNumber';
        }
      }

      print('📱 Requesting phone verification for: $phoneNumber');
      print('🔍 Is Login: ${event.isLogin}');

      // Check if user exists in Firestore before sending OTP (only for login)
      if (event.isLogin) {
        final existingUserQuery = await FirebaseFirestore.instance
            .collection('users')
            .where('phoneNumber', isEqualTo: phoneNumber)
            .get();
            
        if (existingUserQuery.docs.isEmpty) {
          // User doesn't exist, redirect to signup
          emit(const AuthError(message: 'No account found with this phone number. Please sign up first to create an account.'));
          return;
        }

        print('✅ User exists, proceeding with phone verification');
      }

      // Use a Completer to handle the async callbacks properly
      final Completer<void> completer = Completer<void>();
      
      await FirebaseService.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        onVerificationCompleted: (PhoneAuthCredential credential) async {
          print('✅ Phone verification completed automatically');
          if (!emit.isDone) {
            try {
              final userCredential = await FirebaseAuth.instance.signInWithCredential(credential);
              if (userCredential.user != null && !emit.isDone) {
                await _ensureUserDocumentExists(userCredential.user!);
                emit(AuthAuthenticated(user: userCredential.user!));
              }
            } catch (e) {
              print('Error in auto verification: $e');
              if (!emit.isDone) {
                emit(AuthError(message: 'Auto verification failed: ${e.toString()}'));
              }
            }
          }
          if (!completer.isCompleted) completer.complete();
        },
        onVerificationFailed: (FirebaseAuthException e) {
          print('❌ Phone verification failed: ${e.message}');
          // Check for billing error
          if (e.message != null && e.message!.contains('BILLING_NOT_ENABLED')) {
            if (!emit.isDone) {
              emit(const AuthError(
                message: 'Phone authentication is not available. Please enable billing in Firebase Console or use email/password authentication instead.'
              ));
            }
          } else {
            if (!emit.isDone) {
              emit(AuthError(message: _getPhoneAuthErrorMessage(e.code)));
            }
          }
          if (!completer.isCompleted) completer.complete();
        },
        onCodeSent: (String verificationId, int? resendToken) {
          print('📨 OTP code sent. Verification ID: $verificationId');
          if (!emit.isDone) {
            emit(AuthPhoneVerificationSent(
              verificationId: verificationId,
              phoneNumber: phoneNumber,
              isSignUp: false,
            ));
          }
          if (!completer.isCompleted) completer.complete();
        },
        onCodeAutoRetrievalTimeout: (String verificationId) {
          print('⏰ Auto retrieval timeout for verification ID: $verificationId');
          if (!completer.isCompleted) completer.complete();
        },
      );
      
      // Wait for one of the callbacks to complete
      await completer.future;
      
    } catch (e) {
      print('❌ Phone verification error: $e');
      if (!emit.isDone) {
        emit(const AuthError(message: 'Failed to send OTP. Please try again.'));
      }
    }
  }

  Future<void> _onOtpVerificationRequested(
    AuthOtpVerificationRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(const AuthLoading());

    try {
      print('🔐 Verifying OTP: ${event.otpCode}');
      print('Is SignUp: ${event.isSignUp}');

      final credential = PhoneAuthProvider.credential(
        verificationId: event.verificationId,
        smsCode: event.otpCode,
      );

      final userCredential = await FirebaseAuth.instance.signInWithCredential(credential);
      
      if (userCredential.user != null) {
        print('✅ OTP verification successful');
        
                 // If this is a signup, save additional user data and redirect to login
         if (event.isSignUp && event.fullName != null && event.email != null) {
           print('📝 Processing signup - saving data and signing out');
           
                     // Store user data temporarily
          final userData = {
            'uid': userCredential.user!.uid,
            'fullName': event.fullName!,
            'email': event.email!,
            'phoneNumber': event.phoneNumber!,
            'city': event.city ?? '',
            'displayName': event.fullName!,
          };
           
           // IMMEDIATELY sign out to prevent router redirection
           await FirebaseAuth.instance.signOut();
           print('✅ User signed out immediately after signup OTP verification');
           
           // Save user data to Firestore using the stored data
           await _saveUserDataToFirestoreWithoutAuth(userData);
           
           print('✅ User data saved successfully');
           
           // Emit signup success to redirect to login page
           emit(const AuthSignUpSuccess(message: 'You are successfully registered! Please login to continue.'));
         } else {
           // For login, just ensure user document exists and authenticate
           await _ensureUserDocumentExists(userCredential.user!);
           // Emit authenticated state - this will trigger navigation to home
           emit(AuthAuthenticated(user: userCredential.user!));
         }
      } else {
        emit(const AuthError(message: 'OTP verification failed. Please try again.'));
      }
    } on FirebaseAuthException catch (e) {
      print('❌ OTP verification failed: ${e.message}');
      emit(AuthError(message: _getPhoneAuthErrorMessage(e.code)));
    } catch (e) {
      print('❌ OTP verification error: $e');
      emit(const AuthError(message: 'Invalid OTP. Please try again.'));
    }
  }

  Future<void> _onSignUpRequested(
    AuthSignUpRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(const AuthLoading());

    try {
      // Format phone number
      String phoneNumber = event.phoneNumber;
      if (!phoneNumber.startsWith('+')) {
        if (phoneNumber.startsWith('0')) {
          phoneNumber = '+91${phoneNumber.substring(1)}';
        } else {
          phoneNumber = '+91$phoneNumber';
        }
      }

              print('📝 Starting sign up process for: ${event.email}');
        
        // First check if user already exists
        final existingUserQuery = await FirebaseFirestore.instance
            .collection('users')
            .where('phoneNumber', isEqualTo: phoneNumber)
            .get();
            
        if (existingUserQuery.docs.isNotEmpty) {
          emit(const AuthError(message: 'This phone number is already registered. Please login instead.'));
          return;
        }
        
        // Also check by email
        final existingEmailQuery = await FirebaseFirestore.instance
            .collection('users')
            .where('email', isEqualTo: event.email.trim().toLowerCase())
            .get();
            
        if (existingEmailQuery.docs.isNotEmpty) {
          emit(const AuthError(message: 'This email is already registered. Please login instead.'));
          return;
        }


      // Use a Completer to handle the async callbacks properly
      final Completer<void> completer = Completer<void>();

      await FirebaseService.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        onVerificationCompleted: (PhoneAuthCredential credential) async {
          if (!emit.isDone) {
                         try {
               final userCredential = await FirebaseAuth.instance.signInWithCredential(credential);
               if (userCredential.user != null) {
                 // Store user data temporarily
                 final userData = {
                   'uid': userCredential.user!.uid,
                   'fullName': event.name,
                   'email': event.email,
                   'phoneNumber': phoneNumber,
                   'displayName': event.name,
                 };
                 
                 // IMMEDIATELY sign out to prevent router redirection
                 await FirebaseAuth.instance.signOut();
                 
                 // Save user data to Firestore using the stored data
                 await _saveUserDataToFirestoreWithoutAuth(userData);
                 
                 if (!emit.isDone) {
                   emit(const AuthSignUpSuccess(message: 'You are successfully registered! Please login to continue.'));
                 }
               }
             } catch (e) {
               if (!emit.isDone) {
                 emit(AuthError(message: 'Sign up failed: ${e.toString()}'));
               }
             }
          }
          if (!completer.isCompleted) completer.complete();
        },
        onVerificationFailed: (FirebaseAuthException e) {
          // Check for billing error
          if (e.message != null && e.message!.contains('BILLING_NOT_ENABLED')) {
            if (!emit.isDone) {
              emit(const AuthError(
                message: 'Phone authentication is not available. Please enable billing in Firebase Console or use email/password authentication instead.'
              ));
            }
          } else {
            if (!emit.isDone) {
              emit(AuthError(message: _getPhoneAuthErrorMessage(e.code)));
            }
          }
          if (!completer.isCompleted) completer.complete();
        },
        onCodeSent: (String verificationId, int? resendToken) {
          print('📨 OTP sent for signup');
          if (!emit.isDone) {
            // Pass signup data to OTP verification page
            emit(AuthPhoneVerificationSent(
              verificationId: verificationId,
              phoneNumber: phoneNumber,
              isSignUp: true,
              fullName: event.name,
              email: event.email,
            ));
          }
          if (!completer.isCompleted) completer.complete();
        },
        onCodeAutoRetrievalTimeout: (String verificationId) {
          // Handle timeout
          if (!completer.isCompleted) completer.complete();
        },
      );
      
      // Wait for one of the callbacks to complete
      await completer.future;
      
    } catch (e) {
      print('❌ Sign up error: $e');
      if (!emit.isDone) {
        emit(const AuthError(message: 'Sign up failed. Please try again.'));
      }
    }
  }

  // Helper method to save user data to Firestore without authenticated user
   Future<void> _saveUserDataToFirestoreWithoutAuth(Map<String, dynamic> userData) async {
     try {
       final firestore = FirebaseFirestore.instance;
       
             // Create user document with provided data
      await firestore.collection('users').doc(userData['uid']).set({
        'uid': userData['uid'],
        'fullName': userData['fullName'].toString().trim(),
        'displayName': userData['displayName'].toString().trim(),
        'email': userData['email'].toString().trim().toLowerCase(),
        'phoneNumber': userData['phoneNumber'],
        'city': userData['city'].toString().trim(),
        'photoURL': '',
        'creditBalance': 0, // Initialize credit balance for new users
        'createdAt': FieldValue.serverTimestamp(),
        'lastUpdated': FieldValue.serverTimestamp(),
        'isPhoneVerified': true, // Phone is verified through OTP
      }, SetOptions(merge: true));
       
       print('✅ User data saved to Firestore successfully (without auth)');
     } catch (e) {
       print('❌ Error saving user data to Firestore: $e');
       throw 'Failed to save user data: ${e.toString()}';
     }
   }

  // Helper method to ensure user document exists (for login)
  Future<void> _ensureUserDocumentExists(User user) async {
    try {
      final firestore = FirebaseFirestore.instance;
      final docRef = firestore.collection('users').doc(user.uid);
      
      final doc = await docRef.get();
      
      if (!doc.exists) {
        print('📝 Creating user document for existing user ${user.uid}');
        
        await docRef.set({
          'uid': user.uid,
          'email': user.email ?? '',
          'phoneNumber': user.phoneNumber ?? '',
          'displayName': user.displayName ?? user.email?.split('@').first ?? 'User',
          'fullName': user.displayName ?? user.email?.split('@').first ?? 'User',
          'city': '', // Empty city for login users (they can update later)
          'photoURL': user.photoURL ?? '',
          'creditBalance': 0,
          'createdAt': FieldValue.serverTimestamp(),
          'lastUpdated': FieldValue.serverTimestamp(),
          'isPhoneVerified': true,
        }, SetOptions(merge: true));
        
        print('✅ User document created');
      } else {
        // Update last login
        await docRef.update({
          'lastLogin': FieldValue.serverTimestamp(),
        });
      }
    } catch (e) {
      print('Error ensuring user document: $e');
      // Don't throw - this is not critical for auth
    }
  }

  String _getPhoneAuthErrorMessage(String code) {
    switch (code) {
      case 'invalid-phone-number':
        return 'The phone number format is invalid. Please enter a valid phone number.';
      case 'too-many-requests':
        return 'Too many requests. Please try again later.';
      case 'session-expired':
        return 'The SMS code has expired. Please request a new code.';
      case 'invalid-verification-code':
        return 'The SMS verification code is invalid. Please check and try again.';
      case 'invalid-verification-id':
        return 'Invalid verification ID. Please request a new code.';
      case 'quota-exceeded':
        return 'SMS quota exceeded. Please try again later.';
      case 'missing-phone-number':
        return 'Phone number is required for verification.';
      case 'credential-already-in-use':
        return 'This phone number is already associated with another account.';
      default:
        return 'Phone verification failed. Please try again.';
    }
  }
  
  @override
  Future<void> close() {
    _authStateSubscription?.cancel();
    return super.close();
  }
}