import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import 'dart:async';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/routes/app_routes.dart';
import '../../bloc/auth_bloc.dart';
import '../widgets/otp_input_field.dart';
import '../widgets/gradient_button.dart';

class OtpVerificationPage extends StatefulWidget {
  final String verificationId;
  final String phoneNumber;
  final bool isSignUp;
  final String? userName;
  final String? userEmail;
  final String? userCity;

  const OtpVerificationPage({
    super.key,
    required this.verificationId,
    required this.phoneNumber,
    this.isSignUp = false,
    this.userName,
    this.userEmail,
    this.userCity,
  });

  @override
  State<OtpVerificationPage> createState() => _OtpVerificationPageState();
}

class _OtpVerificationPageState extends State<OtpVerificationPage>
    with SingleTickerProviderStateMixin {
  final _otpController = TextEditingController();
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  
  Timer? _resendTimer;
  int _resendCountdown = 60;
  bool _canResend = false;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _startResendTimer();
    
    // Debug print to verify data is passed correctly
    print('🔍 OTP Page initialized:');
    print('   - Is SignUp: ${widget.isSignUp}');
    print('   - User Name: ${widget.userName}');
    print('   - User Email: ${widget.userEmail}');
    print('   - User City: ${widget.userCity}');
    print('   - Phone Number: ${widget.phoneNumber}');
  }

  void _initializeAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOutBack,
    ));

    _animationController.forward();
  }

  void _startResendTimer() {
    _canResend = false;
    _resendCountdown = 60;
    
    _resendTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_resendCountdown > 0) {
          _resendCountdown--;
        } else {
          _canResend = true;
          timer.cancel();
        }
      });
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    _otpController.dispose();
    _resendTimer?.cancel();
    super.dispose();
  }

  void _verifyOtp() {
    if (_otpController.text.length == 6) {
      print('🔐 Verifying OTP with signup data:');
      print('   - Is SignUp: ${widget.isSignUp}');
      print('   - Full Name: ${widget.userName}');
      print('   - Email: ${widget.userEmail}');
      print('   - City: ${widget.userCity}');
      
      // Pass all signup data along with OTP verification
      context.read<AuthBloc>().add(
        AuthOtpVerificationRequested(
          verificationId: widget.verificationId,
          otpCode: _otpController.text,
          isSignUp: widget.isSignUp,
          fullName: widget.userName,
          email: widget.userEmail,
          phoneNumber: widget.phoneNumber,
          city: widget.userCity,
        ),
      );
    }
  }

  void _resendOtp() {
    if (_canResend) {
      if (widget.isSignUp && widget.userName != null && widget.userEmail != null) {
        context.read<AuthBloc>().add(
          AuthSignUpRequested(
            name: widget.userName!,
            email: widget.userEmail!,
            phoneNumber: widget.phoneNumber,
            city: widget.userCity ?? '',
          ),
        );
      } else {
        context.read<AuthBloc>().add(
          AuthPhoneVerificationRequested(
            phoneNumber: widget.phoneNumber,
            isLogin: !widget.isSignUp,
          ),
        );
      }
      _startResendTimer();
      _otpController.clear();
    }
  }

  String _formatPhoneNumber(String phoneNumber) {
    if (phoneNumber.startsWith('+91')) {
      final number = phoneNumber.substring(3);
      if (number.length == 10) {
        return '+91 ${number.substring(0, 5)} ${number.substring(5)}';
      }
    }
    return phoneNumber;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocListener<AuthBloc, AuthState>(
        listener: (context, state) {
          if (state is AuthAuthenticated) {
            print('✅ User authenticated successfully after OTP verification');
            // Only allow navigation to home for login, not signup
            if (!widget.isSignUp) {
              // For login, navigate to home
              Navigator.of(context).pushNamedAndRemoveUntil(
                '/home',
                (route) => false,
              );
            } else {
              // For signup, this shouldn't happen as we redirect to login
              print('⚠️ Unexpected authentication during signup flow');
              Navigator.of(context).popUntil((route) => route.isFirst);
              context.go(AppRoutes.login);
            }
          } else if (state is AuthSignUpSuccess) {
            // Show success message and navigate to login
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message),
                backgroundColor: AppColors.success,
                behavior: SnackBarBehavior.floating,
                margin: const EdgeInsets.all(16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            );
            // Navigate to login page
            Navigator.of(context).popUntil((route) => route.isFirst);
            context.go(AppRoutes.login);
          } else if (state is AuthPhoneVerificationSent) {
            // Update verification ID if resent
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: const Text('OTP resent successfully'),
                backgroundColor: AppColors.success,
                behavior: SnackBarBehavior.floating,
                margin: const EdgeInsets.all(16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            );
          } else if (state is AuthError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message),
                backgroundColor: AppColors.error,
                behavior: SnackBarBehavior.floating,
                margin: const EdgeInsets.all(16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            );
          }
        },
        child: Container(
          decoration: const BoxDecoration(
            gradient: AppColors.backgroundGradient,
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: AnimatedBuilder(
                animation: _fadeAnimation,
                builder: (context, child) {
                  return Opacity(
                    opacity: _fadeAnimation.value,
                    child: SlideTransition(
                      position: _slideAnimation,
                      child: Column(
                        children: [
                          // Back Button
                          Row(
                            children: [
                              IconButton(
                                onPressed: () => Navigator.of(context).pop(),
                                icon: const Icon(
                                  Icons.arrow_back_ios,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                            ],
                          ),
                          
                          Expanded(
                            child: Center(
                              child: SingleChildScrollView(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    // Header
                                    _buildHeader(),
                                    
                                    const SizedBox(height: 48),
                                    
                                    // OTP Form
                                    _buildOtpForm(),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
            gradient: AppColors.primaryGradient,
            borderRadius: BorderRadius.circular(25),
            boxShadow: [
              BoxShadow(
                color: AppColors.primaryBlue.withOpacity(0.3),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: const Icon(
            Icons.sms_outlined,
            size: 50,
            color: AppColors.white,
          ),
        ),
        
        const SizedBox(height: 24),
        
        Text(
          widget.isSignUp ? 'Complete Sign Up' : 'Verify Your Phone',
          style: GoogleFonts.poppins(
            fontSize: 28,
            fontWeight: FontWeight.w700,
            color: AppColors.darkGrey,
          ),
        ),
        
        const SizedBox(height: 8),
        
        RichText(
          textAlign: TextAlign.center,
          text: TextSpan(
            style: GoogleFonts.poppins(
              fontSize: 16,
              fontWeight: FontWeight.w400,
              color: AppColors.grey,
            ),
            children: [
              const TextSpan(text: 'Enter the 6-digit code sent to\n'),
              TextSpan(
                text: _formatPhoneNumber(widget.phoneNumber),
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.w600,
                  color: AppColors.primaryBlue,
                ),
              ),
            ],
          ),
        ),
        
        // Show user info if signing up
        if (widget.isSignUp && widget.userName != null) ...[
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: AppColors.lightBlue.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                Text(
                  'Creating account for:',
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: AppColors.grey,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.userName!,
                  style: GoogleFonts.poppins(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.primaryBlue,
                  ),
                ),
                if (widget.userEmail != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    widget.userEmail!,
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                      color: AppColors.grey,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildOtpForm() {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: AppColors.black.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            'Enter OTP',
            style: GoogleFonts.poppins(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: AppColors.darkGrey,
            ),
          ),
          
          const SizedBox(height: 32),
          
          // OTP Input Field
          OtpInputField(
            controller: _otpController,
            onCompleted: (value) => _verifyOtp(),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter the OTP';
              }
              if (value.length != 6) {
                return 'OTP must be 6 digits';
              }
              return null;
            },
          ),
          
          const SizedBox(height: 32),
          
          // Verify Button
          BlocBuilder<AuthBloc, AuthState>(
            builder: (context, state) {
              final isLoading = state is AuthLoading;
              
              return GradientButton(
                onPressed: isLoading ? null : _verifyOtp,
                gradient: AppColors.buttonGradient,
                child: isLoading
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            AppColors.white,
                          ),
                        ),
                      )
                    : Text(
                        widget.isSignUp ? 'Complete Sign Up' : 'Verify OTP',
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: AppColors.white,
                        ),
                      ),
              );
            },
          ),
          
          const SizedBox(height: 24),
          
          // Resend OTP
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Didn't receive the code? ",
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: AppColors.grey,
                ),
              ),
              GestureDetector(
                onTap: _canResend ? _resendOtp : null,
                child: Text(
                  _canResend 
                      ? 'Resend OTP' 
                      : 'Resend in ${_resendCountdown}s',
                  style: GoogleFonts.poppins(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: _canResend 
                        ? AppColors.primaryBlue 
                        : AppColors.grey,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}