import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:RatNawnAI_app/core/services/listingService.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:dio/dio.dart';
import 'dart:io';
import 'dart:async';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/services/download_service.dart';
import '../../../../core/config/api_config.dart';
import '../../../upload/models/processing_job_model.dart';
import '../widgets/listing_result_card.dart';

class DownloadPage extends StatefulWidget {
  const DownloadPage({super.key});

  @override
  State<DownloadPage> createState() => _DownloadPageState();
}

class _DownloadPageState extends State<DownloadPage>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  
  // Download management
  final Map<String, CancelToken> _cancelTokens = {};
  final Map<String, double> _downloadProgress = {};
  bool _hasInitialized = false;
  
  // Selection mode variables
  Set<String> _selectedJobs = {};
  bool _isSelectionMode = false;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    
    // Delay loading to avoid build conflicts
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && !_hasInitialized) {
        _loadListingResults();
        _hasInitialized = true;
      }
    });
  }

  void _initializeAnimations() {
    _animationController = AnimationController(
      duration: ApiConfig.longAnimation,
      vsync: this,
    );
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    _animationController.forward();
  }

  void _loadListingResults() {
    if (!mounted) return;
    
    Future.microtask(() {
      if (mounted) {
        final listingService = Provider.of<ListingService>(context, listen: false);
        // Use the updated getUserJobs which now includes real-time updates
        listingService.getUserJobs();
      }
    });
  }

  @override
  void dispose() {
    // Cancel all active downloads
    _cancelTokens.values.forEach((token) => token.cancel());
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _downloadListing(ProcessingJob job) async {
    try {
      print('🔄 Starting download for job: ${job.id}');
      
      // Check if job has result with download URL
      if (job.result == null || job.result!['excel_download_url'] == null) {
        _showMessage('No download URL available for this job', isError: true);
        return;
      }

      final downloadUrl = job.result!['excel_download_url'] as String;
      print('📥 Download URL: $downloadUrl');

      // Show download dialog
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(
              'Download Options',
              style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading: Icon(Icons.open_in_browser, color: AppColors.primaryBlue),
                  title: Text('Open in Browser', style: GoogleFonts.poppins()),
                  subtitle: Text('View/download using browser', style: GoogleFonts.poppins(fontSize: 12)),
                  onTap: () {
                    Navigator.pop(context);
                    _openInBrowser(downloadUrl);
                  },
                ),
                Divider(),
                ListTile(
                  leading: Icon(Icons.download, color: AppColors.primaryBlue),
                  title: Text('Download to Device', style: GoogleFonts.poppins()),
                  subtitle: Text('Save to Downloads folder', style: GoogleFonts.poppins(fontSize: 12)),
                  onTap: () {
                    Navigator.pop(context);
                    _downloadToDevice(downloadUrl, job.id);
                  },
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Cancel', style: GoogleFonts.poppins()),
              ),
            ],
          );
        },
      );
    } catch (e) {
      print('❌ Download error: $e');
      _showMessage('Download failed: ${e.toString()}', isError: true);
    }
  }

  Future<void> _openInBrowser(String url) async {
    try {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
        _showMessage('Opening in browser...');
      } else {
        _showMessage('Could not open URL', isError: true);
      }
    } catch (e) {
      _showMessage('Error opening URL: ${e.toString()}', isError: true);
    }
  }

  Future<void> _downloadToDevice(String url, String jobId) async {
    try {
      // Request storage permission
      final hasPermission = await DownloadService.requestStoragePermission();
      if (!hasPermission) {
        _showMessage('Storage permission is required to download files', isError: true);
        return;
      }

      // Create filename
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final fileName = 'RatNawnAI_Listing_${jobId.substring(jobId.length.clamp(0, 8))}_$timestamp.xlsx';

      // Create cancel token
      final cancelToken = CancelToken();
      _cancelTokens[jobId] = cancelToken;

      // Update UI to show download started
      setState(() {
        _downloadProgress[jobId] = 0.0;
      });

      // Download file
      final filePath = await DownloadService.downloadFile(
        url: url,
        fileName: fileName,
        cancelToken: cancelToken,
        onProgress: (progress) {
          if (mounted) {
            setState(() {
              _downloadProgress[jobId] = progress;
            });
          }
        },
      );

      // Clean up
      _cancelTokens.remove(jobId);
      if (mounted) {
        setState(() {
          _downloadProgress.remove(jobId);
        });
      }

      // Show success dialog
      _showDownloadSuccessDialog(fileName, filePath);

    } catch (e) {
      // Clean up on error
      _cancelTokens.remove(jobId);
      if (mounted) {
        setState(() {
          _downloadProgress.remove(jobId);
        });
      }

      if (e is DioException && e.type == DioExceptionType.cancel) {
        _showMessage('Download cancelled');
        return;
      }

      print('❌ Download failed: $e');
      
      String errorMessage = 'Download failed: ';
      if (e.toString().contains('403')) {
        errorMessage += 'Access denied. The download link may have expired.';
      } else if (e.toString().contains('404')) {
        errorMessage += 'File not found on server.';
      } else if (e.toString().contains('SocketException')) {
        errorMessage += 'Network error. Please check your connection.';
      } else {
        errorMessage += e.toString();
      }
      
      _showMessage(errorMessage, isError: true);
    }
  }

  void _cancelDownload(String jobId) {
    final cancelToken = _cancelTokens[jobId];
    if (cancelToken != null) {
      cancelToken.cancel();
      _cancelTokens.remove(jobId);
      setState(() {
        _downloadProgress.remove(jobId);
      });
      _showMessage('Download cancelled');
    }
  }

 void _showDownloadSuccessDialog(String fileName, String filePath) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Row(
          children: [
            Icon(Icons.check_circle, color: AppColors.success),
            SizedBox(width: 8),
            Text('Download Complete', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('File saved successfully!', style: GoogleFonts.poppins()),
            SizedBox(height: 16),
            Text('Filename:', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
            SelectableText(fileName, style: GoogleFonts.poppins(fontSize: 14)),
            SizedBox(height: 8),
            Text('Location:', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.lightGrey.withOpacity(0.5),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (Platform.isAndroid) ...[
                    Text(
                      'Internal Storage > Download',
                      style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w600),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Open your file manager app and look in the Downloads folder',
                      style: GoogleFonts.poppins(fontSize: 11, color: AppColors.grey),
                    ),
                  ] else ...[
                    Text(
                      'Files app > On My iPhone > RatNawnAI',
                      style: GoogleFonts.poppins(fontSize: 12),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK', style: GoogleFonts.poppins()),
          ),
        ],
      );
    },
  );
}


  void _showMessage(String message, {bool isError = false}) {
    if (!mounted) return;
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: GoogleFonts.poppins(),
        ),
        backgroundColor: isError ? AppColors.error : AppColors.primaryBlue,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        duration: Duration(seconds: isError ? 4 : 2), // Keep custom logic for different message types
      ),
    );
  }

  void _toggleJobSelection(String jobId) {
    setState(() {
      if (_selectedJobs.contains(jobId)) {
        _selectedJobs.remove(jobId);
        if (_selectedJobs.isEmpty) {
          _isSelectionMode = false;
        }
      } else {
        _selectedJobs.add(jobId);
        _isSelectionMode = true;
      }
    });
  }

  Future<void> _batchDeleteJobs() async {
    if (_selectedJobs.isEmpty) return;

    final count = _selectedJobs.length;
    final confirmDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Delete Multiple Listings',
          style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
        ),
        content: Text(
          'Are you sure you want to delete $count listing${count > 1 ? 's' : ''}? This action cannot be undone.',
          style: GoogleFonts.poppins(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancel', style: GoogleFonts.poppins()),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.error,
              foregroundColor: AppColors.white,
            ),
            child: Text('Delete All', style: GoogleFonts.poppins()),
          ),
        ],
      ),
    );

    if (confirmDelete == true) {
      // Show progress dialog
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Center(
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation(AppColors.primaryBlue),
                    ),
                    SizedBox(height: 16),
                    Text(
                      'Deleting listings...',
                      style: GoogleFonts.poppins(fontSize: 16),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      );

      try {
        final listingService = Provider.of<ListingService>(context, listen: false);
        
        // Delete all selected jobs
        for (final jobId in _selectedJobs) {
          await listingService.deleteJob(jobId);
        }
        
        // Clear selection
        setState(() {
          _selectedJobs.clear();
          _isSelectionMode = false;
        });
        
        // Close progress dialog
        Navigator.pop(context);
        
        _showMessage('$count listing${count > 1 ? 's' : ''} deleted successfully');
        
        // Refresh the list - real-time updates will handle this automatically
        
      } catch (e) {
        Navigator.pop(context);
        _showMessage('Failed to delete some listings: ${e.toString()}', isError: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // Required for AutomaticKeepAliveClientMixin
    
    return Scaffold(
      backgroundColor: AppColors.lightGrey.withOpacity(0.3),
      appBar: AppBar(
        title: Text(
          'Listing Results',
          style: GoogleFonts.poppins(
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: AppColors.white,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            color: AppColors.white,
            border: Border(
              bottom: BorderSide(
                color: AppColors.lightGrey.withOpacity(0.3),
                width: 1,
              ),
            ),
          ),
        ),
        actions: [
          if (_isSelectionMode) ...[
            IconButton(
              onPressed: _batchDeleteJobs,
              icon: Icon(Icons.delete_sweep, color: AppColors.error),
              tooltip: 'Delete selected',
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _selectedJobs.clear();
                  _isSelectionMode = false;
                });
              },
              child: Text(
                'Cancel',
                style: GoogleFonts.poppins(color: AppColors.grey),
              ),
            ),
          ] else ...[
            IconButton(
              onPressed: () {
                Future.microtask(() {
                  if (mounted) {
                    final listingService = Provider.of<ListingService>(context, listen: false);
                    // Force refresh to get latest data
                    listingService.refreshJobs();
                  }
                });
              },
              icon: const Icon(Icons.refresh_rounded),
            ),
          ],
          const SizedBox(width: 8),
        ],
      ),
      body: AnimatedBuilder(
        animation: _fadeAnimation,
        builder: (context, child) {
          return Opacity(
            opacity: _fadeAnimation.value,
            child: _buildListingResults(),
          );
        },
      ),
    );
  }

  Widget _buildListingResults() {
    return Consumer<ListingService>(
      builder: (context, listingService, child) {
        if (listingService.isLoading) {
          return _buildLoadingState();
        } else if (listingService.jobs.isEmpty) {
          return _buildEmptyState();
        } else {
          return _buildResultsList(listingService.jobs);
        }
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: AppColors.primaryBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(30),
              ),
              child: const Icon(
                Icons.inventory_rounded,
                size: 60,
                color: AppColors.primaryBlue,
              ),
            ),
            const SizedBox(height: 32),
            Text(
              'No Listings Yet',
              style: GoogleFonts.poppins(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                color: AppColors.darkGrey,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Create your first smart listing to see\nprocessed results here',
              style: GoogleFonts.poppins(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: AppColors.grey,
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pushNamed(context, '/upload');
              },
              icon: const Icon(Icons.auto_awesome),
              label: Text(
                'Create Listing',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
                foregroundColor: AppColors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 16,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return const Center(
      child: CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation(AppColors.primaryBlue),
      ),
    );
  }

  Widget _buildResultsList(List<ProcessingJob> jobs) {
    return RefreshIndicator(
      onRefresh: () async {
        final listingService = Provider.of<ListingService>(context, listen: false);
        // Use force refresh method for pull-to-refresh
        await listingService.refreshJobs();
      },
      color: AppColors.primaryBlue,
      child: ListView.builder(
        padding: const EdgeInsets.all(20),
        itemCount: jobs.length,
        itemBuilder: (context, index) {
          final job = jobs[index];
          final isSelected = _selectedJobs.contains(job.id);
          final downloadProgress = _downloadProgress[job.id];
          final isDownloading = downloadProgress != null;
          
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: GestureDetector(
              onLongPress: () => _toggleJobSelection(job.id),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: isSelected
                      ? Border.all(color: AppColors.primaryBlue, width: 2)
                      : null,
                ),
                child: Stack(
                  children: [
                    ListingResultCard(
                      job: job,
                      onDownload: job.isCompleted && !isDownloading 
                          ? () => _downloadListing(job) 
                          : null,

                      onDelete: () => _deleteJob(job),
                    ),
                    
                    // Download progress overlay
                    if (isDownloading)
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Center(
                            child: Container(
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  CircularProgressIndicator(
                                    value: downloadProgress,
                                    valueColor: AlwaysStoppedAnimation(AppColors.primaryBlue),
                                  ),
                                  SizedBox(height: 16),
                                  Text(
                                    'Downloading... ${(downloadProgress * 100).toInt()}%',
                                    style: GoogleFonts.poppins(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  TextButton(
                                    onPressed: () => _cancelDownload(job.id),
                                    child: Text(
                                      'Cancel',
                                      style: GoogleFonts.poppins(
                                        color: AppColors.error,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }



  void _deleteJob(ProcessingJob job) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Delete Listing',
          style: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: AppColors.darkGrey,
          ),
        ),
        content: Text(
          'Are you sure you want to delete this listing result? This action cannot be undone.',
          style: GoogleFonts.poppins(
            fontSize: 14,
            fontWeight: FontWeight.w400,
            color: AppColors.grey,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: GoogleFonts.poppins(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: AppColors.grey,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _performDelete(job);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.error,
              foregroundColor: AppColors.white,
            ),
            child: Text(
              'Delete',
              style: GoogleFonts.poppins(
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _performDelete(ProcessingJob job) async {
    try {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Center(
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation(AppColors.primaryBlue),
                    ),
                    SizedBox(height: 16),
                    Text(
                      'Deleting listing...',
                      style: GoogleFonts.poppins(fontSize: 16),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      );

      final listingService = Provider.of<ListingService>(context, listen: false);
      await listingService.deleteJob(job.id);
      
      Navigator.pop(context);
      
      _showMessage('Listing deleted successfully');
      
      // Real-time listener will handle the update automatically
      
    } catch (e) {
      if (Navigator.canPop(context)) {
        Navigator.pop(context);
      }
      
      _showMessage('Failed to delete listing: ${e.toString()}', isError: true);
    }
  }
}