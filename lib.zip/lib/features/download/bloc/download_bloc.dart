import 'dart:io';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:dio/dio.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../core/services/firebase_service.dart';
import '../../../core/services/fashion_ai_service.dart';
import '../../../core/config/api_config.dart';

// Events
abstract class DownloadEvent extends Equatable {
  const DownloadEvent();

  @override
  List<Object> get props => [];
}

class LoadDownloadableVideos extends DownloadEvent {
  const LoadDownloadableVideos();
}

class DownloadVideo extends DownloadEvent {
  final DownloadableVideo video;

  const DownloadVideo({required this.video});

  @override
  List<Object> get props => [video];
}

class DeleteDownloadedVideo extends DownloadEvent {
  final String videoId;

  const DeleteDownloadedVideo({required this.videoId});

  @override
  List<Object> get props => [videoId];
}

class CancelDownload extends DownloadEvent {
  final String videoId;

  const CancelDownload({required this.videoId});

  @override
  List<Object> get props => [videoId];
}

class RefreshDownloadableVideos extends DownloadEvent {
  const RefreshDownloadableVideos();
}

class DownloadExcelFile extends DownloadEvent {
  final String url;
  final String fileName;

  const DownloadExcelFile({
    required this.url,
    required this.fileName,
  });

  @override
  List<Object> get props => [url, fileName];
}

// States
abstract class DownloadState extends Equatable {
  const DownloadState();

  @override
  List<Object> get props => [];
}

class DownloadInitial extends DownloadState {
  const DownloadInitial();
}

class DownloadLoading extends DownloadState {
  const DownloadLoading();
}

class DownloadLoaded extends DownloadState {
  final List<DownloadableVideo> videos;
  final Map<String, double> downloadProgress;

  const DownloadLoaded({
    required this.videos,
    this.downloadProgress = const {},
  });

  @override
  List<Object> get props => [videos, downloadProgress];

  DownloadLoaded copyWith({
    List<DownloadableVideo>? videos,
    Map<String, double>? downloadProgress,
  }) {
    return DownloadLoaded(
      videos: videos ?? this.videos,
      downloadProgress: downloadProgress ?? this.downloadProgress,
    );
  }
}

class DownloadError extends DownloadState {
  final String message;

  const DownloadError({required this.message});

  @override
  List<Object> get props => [message];
}

class DownloadSuccess extends DownloadState {
  final String fileName;
  final String filePath;

  const DownloadSuccess({
    required this.fileName,
    required this.filePath,
  });

  @override
  List<Object> get props => [fileName, filePath];
}

class ExcelDownloadInProgress extends DownloadState {
  final double progress;
  final String fileName;

  const ExcelDownloadInProgress({
    required this.progress,
    required this.fileName,
  });

  @override
  List<Object> get props => [progress, fileName];
}

class ExcelDownloadSuccess extends DownloadState {
  final String fileName;
  final String filePath;

  const ExcelDownloadSuccess({
    required this.fileName,
    required this.filePath,
  });

  @override
  List<Object> get props => [fileName, filePath];
}

// BLoC
class DownloadBloc extends Bloc<DownloadEvent, DownloadState> {
  final Dio _dio = Dio();
  final Map<String, CancelToken> _cancelTokens = {};
  final FashionAIService _fashionAIService = FashionAIService();

  DownloadBloc() : super(const DownloadInitial()) {
    on<LoadDownloadableVideos>(_onLoadDownloadableVideos);
    on<RefreshDownloadableVideos>(_onRefreshDownloadableVideos);
    on<DownloadVideo>(_onDownloadVideo);
    on<CancelDownload>(_onCancelDownload);
    on<DownloadExcelFile>(_onDownloadExcelFile);
    
    // Initialize the FashionAI service
    _fashionAIService.initialize();
  }

  Future<void> _onLoadDownloadableVideos(
    LoadDownloadableVideos event,
    Emitter<DownloadState> emit,
  ) async {
    emit(const DownloadLoading());
    try {
      final videos = await FirebaseService.getDownloadableVideos();
      emit(DownloadLoaded(videos: videos));

    } catch (e) {
      emit(DownloadError(message: e.toString()));
    }
  }

  Future<void> _onRefreshDownloadableVideos(
    RefreshDownloadableVideos event,
    Emitter<DownloadState> emit,
  ) async {
    try {
      final videos = await FirebaseService.getDownloadableVideos();
      if (state is DownloadLoaded) {
        final currentState = state as DownloadLoaded;
        emit(currentState.copyWith(videos: videos));
      } else {
        emit(DownloadLoaded(videos: videos));
      }
    } catch (e) {
      emit(DownloadError(message: e.toString()));
    }
  }

  Future<void> _onDownloadVideo(
    DownloadVideo event,
    Emitter<DownloadState> emit,
  ) async {
    if (state is! DownloadLoaded) return;
    final currentState = state as DownloadLoaded;
    final video = event.video;

    try {
      print('🚀 Starting download for: ${video.title}');
      
      // Request storage permission
      await _requestStoragePermission();
      
      // Create file name
      final fileName = '${video.title.replaceAll(RegExp(r'[^\w\s-]'), '_')}_${DateTime.now().millisecondsSinceEpoch}.mp4';
      
      // Get temporary download path
      final tempDir = await getTemporaryDirectory();
      final tempFilePath = '${tempDir.path}/$fileName';

      // Create cancel token
      final cancelToken = CancelToken();
      _cancelTokens[video.id] = cancelToken;

      print('📥 Starting download from: ${video.videoUrl}');
      
      // Download to temporary location first
      await _dio.download(
        video.videoUrl,
        tempFilePath,
        cancelToken: cancelToken,
        options: Options(
          receiveTimeout: ApiConfig.downloadReceiveTimeout,
          sendTimeout: ApiConfig.downloadSendTimeout,
        ),
        onReceiveProgress: (received, total) {
          if (total != -1) {
            final progress = received / total;
            final updatedProgress = Map<String, double>.from(currentState.downloadProgress);
            updatedProgress[video.id] = progress;
            print('📊 Download progress: ${(progress * 100).toStringAsFixed(1)}%');
            emit(currentState.copyWith(downloadProgress: updatedProgress));
          }
        },
      );

      // Save to gallery using Gal
      await Gal.putVideo(tempFilePath);
      print('✅ Video saved to gallery successfully');
      
      // Clean up temporary file
      await File(tempFilePath).delete();
      
      // Remove cancel token and progress tracking
      _cancelTokens.remove(video.id);
      final updatedProgress = Map<String, double>.from(currentState.downloadProgress);
      updatedProgress.remove(video.id);
      
      emit(currentState.copyWith(downloadProgress: updatedProgress));
      

      
      emit(DownloadSuccess(fileName: fileName, filePath: 'Gallery'));

    } catch (e) {
      _cancelTokens.remove(video.id);
      final updatedProgress = Map<String, double>.from(currentState.downloadProgress);
      updatedProgress.remove(video.id);
      emit(currentState.copyWith(downloadProgress: updatedProgress));
      
      if (e is DioException && e.type == DioExceptionType.cancel) {
        print('🚫 Download was cancelled');
        return;
      }
      
      print('❌ Download failed: $e');
      emit(DownloadError(message: 'Download failed: ${e.toString()}'));
    }
  }

  void _onCancelDownload(
    CancelDownload event,
    Emitter<DownloadState> emit,
  ) {
    final cancelToken = _cancelTokens[event.videoId];
    if (cancelToken != null) {
      cancelToken.cancel();
      _cancelTokens.remove(event.videoId);
      if (state is DownloadLoaded) {
        final currentState = state as DownloadLoaded;
        final updatedProgress = Map<String, double>.from(currentState.downloadProgress);
        updatedProgress.remove(event.videoId);
        emit(currentState.copyWith(downloadProgress: updatedProgress));
      }
    }
  }

  Future<void> _onDownloadExcelFile(
    DownloadExcelFile event,
    Emitter<DownloadState> emit,
  ) async {
    try {
      print('📥 Starting Excel file download: ${event.fileName}');
      
      // Request storage permission
      await _requestStoragePermission();
      
      emit(ExcelDownloadInProgress(progress: 0.0, fileName: event.fileName));

      // Download the Excel file
      final filePath = await _fashionAIService.downloadExcelFile(
        url: event.url,
        fileName: event.fileName,
        onProgress: (progress) {
          emit(ExcelDownloadInProgress(progress: progress, fileName: event.fileName));
        },
      );

      emit(ExcelDownloadSuccess(fileName: event.fileName, filePath: filePath));



    } catch (e) {
      print('❌ Excel download failed: $e');
      emit(DownloadError(message: 'Excel download failed: ${e.toString()}'));
      

    }
  }

  Future<void> _requestStoragePermission() async {
    try {
      if (Platform.isAndroid) {
        final status = await Permission.storage.request();
        print('📱 Storage permission status: $status');
        
        if (status.isDenied || status.isPermanentlyDenied) {
          print('⚠️ Storage permission denied');
          await Permission.photos.request();
        }
      }
      print('✅ Storage access configured');
    } catch (e) {
      print('⚠️ Permission request failed: $e');
    }
  }
}
