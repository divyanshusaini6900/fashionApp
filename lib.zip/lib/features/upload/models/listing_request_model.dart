class ListingRequest {
  final String userId;
  final List<Map<String, dynamic>> products;
  final DateTime timestamp;

  ListingRequest({
    required this.userId,
    required this.products,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  Map<String, dynamic> toJson() {
    return {
      'user_id': userId,
      'products': products,
      'timestamp': timestamp.toIso8601String(),
    };
  }

  factory ListingRequest.fromJson(Map<String, dynamic> json) {
    return ListingRequest(
      userId: json['user_id'],
      products: List<Map<String, dynamic>>.from(
        (json['products'] as List).map((e) => Map<String, dynamic>.from(e)),
      ),
      timestamp: DateTime.parse(json['timestamp']),
    );
  }
}
