import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/responsive_utils.dart';
import '../../../../core/config/api_config.dart';
import '../../../../core/routes/app_routes.dart';
import '../../../../core/utils/credit_formatter.dart';
import '../../../navbar/safe_state_mixin.dart';
import '../../../auth/bloc/auth_bloc.dart';
import '../../../download/bloc/download_bloc.dart';
import '../../../wallet/bloc/wallet_bloc.dart';
import '../../../user/bloc/user_bloc.dart';

class HomeDashboard extends StatefulWidget {
  final Function(int)? onNavigateToTab;
  
  const HomeDashboard({
    super.key,
    this.onNavigateToTab,
  });

  @override
  State<HomeDashboard> createState() => HomeDashboardState();
}

class HomeDashboardState extends State<HomeDashboard>
    with SingleTickerProviderStateMixin, AutomaticKeepAliveClientMixin, SafeStateMixin {
  
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  bool _hasInitialized = false;
  // Performance metrics (per-user)
  String _successRateText = '--';
  String _avgTimeText = '--';
  
  // Store bloc references to avoid context lookups during disposal
  DownloadBloc? _downloadBloc;
  WalletBloc? _walletBloc;
  UserBloc? _userBloc;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    // Delay initialization to avoid build conflicts
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && !_hasInitialized) {
        _initializeBlocs();
        _loadDashboardData();
        _hasInitialized = true;
      }
    });
  }

  void _initializeBlocs() {
    if (!mounted) return;
    
    try {
      _downloadBloc = context.read<DownloadBloc>();
      _walletBloc = context.read<WalletBloc>();
      _userBloc = context.read<UserBloc>();
    } catch (e) {
      debugPrint('Error initializing blocs: $e');
    }
  }

  void _initializeAnimations() {
    _animationController = AnimationController(
      duration: ApiConfig.extraLongAnimation,
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: const Interval(0.0, 0.6, curve: Curves.easeInOut),
    ));

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: const Interval(0.2, 1.0, curve: Curves.easeOutBack),
    ));

    _animationController.forward();
  }

  void _loadDashboardData() {
    if (!mounted) return;
    
    try {
      // Use the stored bloc references
      _downloadBloc?.add(const LoadDownloadableVideos());
      _walletBloc?.add(const StartWalletStream());
      _userBloc?.add(const StartUserDataStream());
      _loadPerformanceMetrics();
    } catch (e) {
      debugPrint('Error loading dashboard data: $e');
    }
  }

  Future<void> _loadPerformanceMetrics() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final snapshot = await FirebaseFirestore.instance
          .collection('listing_jobs')
          .where('userId', isEqualTo: user.uid)
          .orderBy('createdAt', descending: true)
          .limit(100)
          .get();

      int completed = 0;
      int failed = 0;
      int totalSeconds = 0;
      int numDurations = 0;

      for (final doc in snapshot.docs) {
        final data = doc.data();
        final status = (data['status'] ?? '').toString();
        if (status == 'completed') {
          completed++;
          final created = data['createdAt'];
          final completedAt = data['completedAt'];
          DateTime? createdDt;
          DateTime? completedDt;
          try {
            if (created is Timestamp) createdDt = created.toDate();
            if (completedAt is Timestamp) completedDt = completedAt.toDate();
          } catch (_) {}
          if (createdDt != null && completedDt != null) {
            totalSeconds += completedDt.difference(createdDt).inSeconds;
            numDurations++;
          }
        } else if (status == 'failed') {
          failed++;
        }
      }

      String successText = '--';
      String avgTimeText = '--';
      final attempts = completed + failed;
      if (attempts > 0) {
        final rate = (completed / attempts * 100).clamp(0, 100);
        successText = '${rate.toStringAsFixed(0)}%';
      }
      if (numDurations > 0) {
        final avgSeconds = totalSeconds / numDurations;
        final avgMinutes = avgSeconds / 60.0;
        avgTimeText = '${avgMinutes.toStringAsFixed(1)}m';
      }

      if (mounted) {
        setState(() {
          _successRateText = successText;
          _avgTimeText = avgTimeText;
        });
      }
    } catch (e) {
      debugPrint('Error loading performance metrics: $e');
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    
    return Scaffold(
      backgroundColor: AppColors.backgroundBlue,
      body: SafeArea(
        child: BlocBuilder<AuthBloc, AuthState>(
          builder: (context, authState) {
            final user = authState is AuthAuthenticated ? authState.user : null;
            
            return AnimatedBuilder(
              animation: _fadeAnimation,
              builder: (context, child) {
                return Opacity(
                  opacity: _fadeAnimation.value,
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: CustomScrollView(
                      slivers: [
                        // Modern App Bar
                        _buildModernAppBar(user),
                        
                        // Dashboard Content
                        SliverPadding(
                          padding: ResponsiveUtils.getResponsivePadding(
                            context,
                            mobile: const EdgeInsets.all(16),
                            tablet: const EdgeInsets.all(24),
                            desktop: const EdgeInsets.all(32),
                          ),
                          sliver: SliverList(
                            delegate: SliverChildListDelegate([
                              // User Overview Card
                              _buildUserOverviewCard(user),
                              
                              const SizedBox(height: 24),
                              
                              // Quick Actions
                              _buildQuickActions(),
                              
                              const SizedBox(height: 24),
                              
                              // Performance Cards
                              _buildPerformanceCards(),
                              
                              const SizedBox(height: 24),
                              
                              // Recent Activity
                              _buildRecentActivity(),
                              
                              const SizedBox(height: 100), // Bottom padding for navigation
                            ]),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }

  Widget _buildModernAppBar(User? user) {
    return SliverAppBar(
      expandedHeight: 140,
      floating: false,
      pinned: true,
      backgroundColor: AppColors.white,
      foregroundColor: AppColors.textPrimary,
      elevation: 0,
      
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [AppColors.white, AppColors.backgroundBlue],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Row(
                    children: [
                      // User Avatar
                      GestureDetector(
                        onTap: () {
                          context.push(AppRoutes.profile);
                        },
                        child: Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: AppColors.primaryGradient,
                            border: Border.all(
                              color: AppColors.white,
                              width: 2,
                            ),
                          ),
                          child: Icon(
                            Icons.person,
                            color: AppColors.white,
                            size: 24,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      // User Info
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Good ${_getGreeting()}!',
                              style: GoogleFonts.poppins(
                                fontSize: 14,
                                fontWeight: FontWeight.w400,
                                color: AppColors.textSecondary,
                              ),
                            ),
                            BlocBuilder<UserBloc, UserState>(
                              builder: (context, userState) {
                                String displayName = 'User';
                                
                                if (userState is UserLoaded) {
                                  displayName = userState.displayName;
                                } else if (user != null) {
                                  displayName = user.displayName ?? 
                                              user.email?.split('@').first ?? 
                                              'User';
                                }
                                
                                return Text(
                                  displayName,
                                  style: GoogleFonts.poppins(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.textPrimary,
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                      // Wallet credit display and notifications
                      Row(
                        children: [
                          // Wallet credit display - CLICKABLE
                          BlocBuilder<WalletBloc, WalletState>(
                            builder: (context, walletState) {
                              final balance = walletState is WalletLoaded ? walletState.balance : 0.0;
                              return GestureDetector(
                                onTap: () {
                                  // Navigate to wallet page
                                  context.push(AppRoutes.wallet);
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: AppColors.warning.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(
                                      color: AppColors.warning.withOpacity(0.3),
                                      width: 1,
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Container(
                                        width: 20,
                                        height: 20,
                                        decoration: BoxDecoration(
                                          color: AppColors.warning,
                                          shape: BoxShape.circle,
                                        ),
                                        child: Center(
                                          child: Text(
                                            '₹',
                                            style: GoogleFonts.poppins(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w700,
                                              color: AppColors.white,
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        '$balance',
                                        style: GoogleFonts.poppins(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w700,
                                          color: AppColors.warning,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                          const SizedBox(width: 12),
                          // Notifications icon
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: AppColors.white,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.shadowColor.withOpacity(0.1),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Stack(
                              children: [
                                Center(
                                  child: Icon(
                                    Icons.notifications_outlined,
                                    color: AppColors.textPrimary,
                                    size: 20,
                                  ),
                                ),
                                // Notification badge
                                Positioned(
                                  top: 8,
                                  right: 8,
                                  child: Container(
                                    width: 8,
                                    height: 8,
                                    decoration: BoxDecoration(
                                      color: AppColors.error,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
        centerTitle: false,
        title: Container(), // Empty title since we handle it in background
      ),
    );
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Morning';
    if (hour < 17) return 'Afternoon';
    return 'Evening';
  }

  Widget _buildUserOverviewCard(User? user) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: AppColors.primaryGradient,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryBlue.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Welcome Back!',
            style: GoogleFonts.poppins(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: AppColors.white,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Ready to create amazing listings with AI?',
            style: GoogleFonts.poppins(
              fontSize: 14,
              fontWeight: FontWeight.w400,
              color: AppColors.white.withOpacity(0.9),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {
                    widget.onNavigateToTab?.call(1);
                  },
                  icon: const Icon(Icons.auto_awesome, size: 18),
                  label: const Text('Start Creating'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.white,
                    foregroundColor: AppColors.primaryBlue,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Actions',
          style: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildQuickActionCard(
                title: 'Create Listing',
                subtitle: 'AI-powered listings',
                icon: Icons.auto_awesome,
                color: AppColors.primaryBlue,
                onTap: () {
                  // Navigate to listing page (tab index 1)
                  widget.onNavigateToTab?.call(1);
                },
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildQuickActionCard(
                title: 'My Downloads',
                subtitle: 'View generated content',
                icon: Icons.download_rounded,
                color: AppColors.success,
                onTap: () {
                  // Navigate to downloads page (tab index 2)
                  widget.onNavigateToTab?.call(2);
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildQuickActionCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.shadowColor,
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: color,
                size: 24,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              title,
              style: GoogleFonts.poppins(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: GoogleFonts.poppins(
                fontSize: 12,
                fontWeight: FontWeight.w400,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPerformanceCards() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Performance',
          style: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildPerformanceCard(
                title: 'Success Rate',
                value: _successRateText,
                subtitle: 'Generation success',
                color: AppColors.success,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildPerformanceCard(
                title: 'Avg. Time',
                value: _avgTimeText,
                subtitle: 'Per generation',
                color: AppColors.warning,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildPerformanceCard({
    required String title,
    required String value,
    required String subtitle,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppColors.shadowColor,
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            value,
            style: GoogleFonts.poppins(
              fontSize: 28,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: GoogleFonts.poppins(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
          ),
          Text(
            subtitle,
            style: GoogleFonts.poppins(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentActivity() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Recent Activity',
          style: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: AppColors.shadowColor,
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: BlocBuilder<DownloadBloc, DownloadState>(
            builder: (context, downloadState) {
              return BlocBuilder<WalletBloc, WalletState>(
                builder: (context, walletState) {
                  final hasListings = downloadState is DownloadLoaded && downloadState.videos.isNotEmpty;
                  final hasCredits = walletState is WalletLoaded && walletState.balance > 0.0;
                  
                  List<Widget> activities = [];
                  
                  if (hasListings) {
                    activities.add(
                      _buildActivityItem(
                        icon: Icons.auto_awesome,
                        title: 'Listing Generated',
                        subtitle: 'Recently',
                        color: AppColors.primaryBlue,
                      ),
                    );
                    
                    if (activities.isNotEmpty) {
                      activities.add(Divider(color: AppColors.borderColor, height: 1));
                    }
                    
                    activities.add(
                      _buildActivityItem(
                        icon: Icons.download_rounded,
                        title: 'Listing Downloaded',
                        subtitle: 'Available now',
                        color: AppColors.success,
                      ),
                    );
                  }
                  
                  if (hasCredits && activities.isNotEmpty) {
                    activities.add(Divider(color: AppColors.borderColor, height: 1));
                  }
                  
                  if (hasCredits) {
                    activities.add(
                      _buildActivityItem(
                        icon: Icons.account_balance_wallet,
                        title: 'Account Active',
                        subtitle: '${CreditFormatter.formatCreditsWithUnit(walletState.balance)} available',
                        color: AppColors.warning,
                      ),
                    );
                  }
                  
                  // Show welcome message if no activities
                  if (activities.isEmpty) {
                    activities.add(
                      _buildActivityItem(
                        icon: Icons.waving_hand,
                        title: 'Welcome to RatNawnAI!',
                        subtitle: 'Start creating your first listing',
                        color: AppColors.primaryBlue,
                      ),
                    );
                  }
                  
                  return Column(children: activities);
                },
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildActivityItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
  }) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              color: color,
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.poppins(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
                Text(
                  subtitle,
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            Icons.chevron_right,
            color: AppColors.textSecondary,
            size: 20,
          ),
        ],
      ),
    );
  }
}

// Helper widget for responsive building
class ResponsiveBuilder extends StatelessWidget {
  final Widget Function(BuildContext context, bool isMobile, bool isTablet, bool isDesktop) builder;

  const ResponsiveBuilder({super.key, required this.builder});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 600;
    final isTablet = screenWidth >= 600 && screenWidth < 900;
    final isDesktop = screenWidth >= 900;
    
    return builder(context, isMobile, isTablet, isDesktop);
  }
}