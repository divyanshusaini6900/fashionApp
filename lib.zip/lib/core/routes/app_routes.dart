import 'dart:async';

import 'package:RatNawnAI_app/features/wallet/walletPage.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../features/splash/presentation/pages/splash_page.dart';
import '../../features/auth/presentation/pages/login_page.dart';
import '../../features/auth/presentation/pages/signup_page.dart';
import '../../features/home/presentation/pages/home_page.dart';
import '../../features/upload/presentation/pages/smart_listing_page.dart';
import '../../features/download/presentation/pages/download_page.dart';
import '../../features/profile/presentation/pages/profile_page.dart';
import '../../features/fashion_ai/screens/fashion_ai_screen.dart';
import '../../features/pricing/presentation/pages/pricing_page.dart';


class AppRoutes {
  static const String splash = '/';
  static const String login = '/login';
  static const String signup = '/signup';
  static const String home = '/home';
  static const String listing = '/listing';
  static const String fashionAI = '/fashion-ai';
  static const String download = '/download';
  static const String profile = '/profile';
  static const String pricing = '/pricing';
  static const String wallet = '/wallet';

  static final GoRouter router = GoRouter(
    initialLocation: splash,
    refreshListenable: GoRouterRefreshStream(FirebaseAuth.instance.authStateChanges()),
    redirect: (context, state) {
      print('🔄 Router redirect - Location: ${state.matchedLocation}');
      
      final isLoggedIn = FirebaseAuth.instance.currentUser != null;
      final isLoggingIn = state.matchedLocation == login;
      final isSigningUp = state.matchedLocation == signup;
      final isSplash = state.matchedLocation == splash;

      print('👤 User logged in: $isLoggedIn');
      print('📍 Current location: ${state.matchedLocation}');

      // Always allow splash screen
      if (isSplash) {
        print('✅ Allowing splash screen');
        return null;
      }

      // If not logged in and trying to access protected routes, redirect to login
      if (!isLoggedIn && !isLoggingIn && !isSigningUp) {
        print('🔐 Not logged in, redirecting to login');
        return login;
      }

      // If logged in and on login or signup page, redirect to home
      if (isLoggedIn && (isLoggingIn || isSigningUp)) {
        print('🏠 Logged in, redirecting to home');
        return home;
      }

      print('✅ No redirect needed');
      return null;
    },
    routes: [
      GoRoute(
        path: splash,
        name: 'splash',
        pageBuilder: (context, state) => _buildPageWithFadeTransition(
          context,
          state,
          const SplashPage(),
        ),
      ),
      GoRoute(
        path: login,
        name: 'login',
        pageBuilder: (context, state) => _buildPageWithSlideTransition(
          context,
          state,
          const LoginPage(),
        ),
      ),
      GoRoute(
        path: signup,
        name: 'signup',
        pageBuilder: (context, state) => _buildPageWithSlideTransition(
          context,
          state,
          const SignUpPage(),
        ),
      ),
      GoRoute(
        path: home,
        name: 'home',
        pageBuilder: (context, state) => _buildPageWithSlideTransition(
          context,
          state,
          const HomePage(),
        ),
      ),
      GoRoute(
        path: listing,
        name: 'listing',
        pageBuilder: (context, state) => _buildPageWithSlideTransition(
          context,
          state,
          const SmartListingPage(),
        ),
      ),
      GoRoute(
        path: fashionAI,
        name: 'fashion-ai',
        pageBuilder: (context, state) => _buildPageWithSlideTransition(
          context,
          state,
          const FashionAIScreen(),
        ),
      ),
      GoRoute(
        path: download,
        name: 'download',
        pageBuilder: (context, state) => _buildPageWithSlideTransition(
          context,
          state,
          const DownloadPage(),
        ),
      ),
      GoRoute(
        path: profile,
        name: 'profile',
        pageBuilder: (context, state) => _buildPageWithSlideTransition(
          context,
          state,
          const ProfilePage(),
        ),
      ),
      GoRoute(
        path: pricing,
        name: 'pricing',
        pageBuilder: (context, state) => _buildPageWithSlideTransition(
          context,
          state,
          const RatnawnAIPricingPage(),
        ),
      ),
      GoRoute(
        path: wallet,
        name: 'wallet',
        pageBuilder: (context, state) => _buildPageWithSlideTransition(
          context,
          state,
          const WalletPage(),
        ),
      ),
    ],
  );

  static Page<void> _buildPageWithSlideTransition(
    BuildContext context,
    GoRouterState state,
    Widget child,
  ) {
    return CustomTransitionPage<void>(
      key: state.pageKey,
      child: child,
      transitionDuration: const Duration(milliseconds: 300),
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        return SlideTransition(
          position: animation.drive(
            Tween(
              begin: const Offset(1.0, 0.0),
              end: Offset.zero,
            ).chain(
              CurveTween(curve: Curves.easeInOut),
            ),
          ),
          child: child,
        );
      },
    );
  }

  static Page<void> _buildPageWithFadeTransition(
    BuildContext context,
    GoRouterState state,
    Widget child,
  ) {
    return CustomTransitionPage<void>(
      key: state.pageKey,
      child: child,
      transitionDuration: const Duration(milliseconds: 300),
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        return FadeTransition(
          opacity: animation.drive(
            CurveTween(curve: Curves.easeInOut),
          ),
          child: child,
        );
      },
    );
  }
}

// Helper class to make GoRouter listen to auth state changes
class GoRouterRefreshStream extends ChangeNotifier {
  late final StreamSubscription<dynamic> _subscription;

  GoRouterRefreshStream(Stream<dynamic> stream) {
    notifyListeners();
    _subscription = stream.asBroadcastStream().listen(
      (dynamic _) {
        notifyListeners();
      },
    );
  }

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }
}