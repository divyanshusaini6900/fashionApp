// lib/core/services/download_service.dart
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:gal/gal.dart';
import '../config/api_config.dart';

class DownloadService {
  static final Dio _dio = Dio();
  
  static Future<bool> requestStoragePermission() async {
    if (Platform.isAndroid) {
      final DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
      final AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      
      print('📱 Android SDK: ${androidInfo.version.sdkInt}');
      
      // Android 13+ (API 33+) doesn't need storage permission for downloads
      if (androidInfo.version.sdkInt >= 33) {
        print('✅ Android 13+: No storage permission needed for downloads');
        return true;
      }
      // Android 11-12 (API 30-32)
      else if (androidInfo.version.sdkInt >= 30) {
        print('✅ Android 11-12: Using scoped storage');
        return true;
      }
      // Android 10 and below
      else {
        final status = await Permission.storage.status;
        if (status.isDenied) {
          final result = await Permission.storage.request();
          return result.isGranted;
        }
        return status.isGranted;
      }
    }
    return true; // iOS doesn't need special permissions
  }

  static Future<Directory?> getDownloadDirectory() async {
    if (Platform.isAndroid) {
      try {
        // Try public Downloads directory first
        final Directory publicDownloadsDir = Directory('/storage/emulated/0/Download');
        if (await publicDownloadsDir.exists()) {
          print('✅ Using public Downloads directory: ${publicDownloadsDir.path}');
          return publicDownloadsDir;
        }
        
        // Alternative with 's'
        final Directory altDownloadsDir = Directory('/storage/emulated/0/Downloads');
        if (await altDownloadsDir.exists()) {
          print('✅ Using alternative Downloads directory: ${altDownloadsDir.path}');
          return altDownloadsDir;
        }
        
        // Fallback to app-specific directory
        final Directory? externalDir = await getExternalStorageDirectory();
        if (externalDir != null) {
          final appDownloadDir = Directory('${externalDir.path}/Download');
          if (!await appDownloadDir.exists()) {
            await appDownloadDir.create(recursive: true);
          }
          print('⚠️ Using app-specific download directory: ${appDownloadDir.path}');
          return appDownloadDir;
        }
      } catch (e) {
        print('❌ Error accessing download directory: $e');
      }
      
      // Last resort
      return await getApplicationDocumentsDirectory();
    } else {
      // iOS
      return await getApplicationDocumentsDirectory();
    }
  }

  static Future<String> downloadFile({
    required String url,
    required String fileName,
    required CancelToken? cancelToken,
    required Function(double) onProgress,
  }) async {
    // Get download directory
    final Directory? downloadsDir = await getDownloadDirectory();
    if (downloadsDir == null) {
      throw Exception('Could not access download directory');
    }

    final filePath = '${downloadsDir.path}/$fileName';
    print('💾 Downloading to: $filePath');

    // Download file
    await _dio.download(
      url,
      filePath,
      cancelToken: cancelToken,
      options: Options(
        headers: {
          'Accept': '*/*',
          'User-Agent': 'RatNawnAI/1.0',
        },
        responseType: ResponseType.bytes,
        followRedirects: true,
        validateStatus: (status) => status! < 500,
      ),
      onReceiveProgress: (received, total) {
        if (total != -1) {
          final progress = received / total;
          onProgress(progress);
        }
      },
    );

    // Verify file
    final file = File(filePath);
    if (!await file.exists()) {
      throw Exception('File was not saved properly');
    }

    final fileSize = await file.length();
    if (fileSize == 0) {
      await file.delete();
      throw Exception('Downloaded file is empty');
    }

    print('✅ File downloaded successfully. Size: $fileSize bytes');

    // Trigger media scan on Android
    if (Platform.isAndroid) {
      try {
        await Process.run('am', [
          'broadcast',
          '-a',
          'android.intent.action.MEDIA_SCANNER_SCAN_FILE',
          '-d',
          'file://$filePath'
        ]);
        print('✅ Media scan triggered');
      } catch (e) {
        print('⚠️ Could not trigger media scan: $e');
      }
    }

    return filePath;
  }

  static Future<String> downloadVideo({
    required String url,
    required String fileName,
    required CancelToken? cancelToken,
    required Function(double) onProgress,
  }) async {
    // Download to temp first
    final tempDir = await getTemporaryDirectory();
    final tempFilePath = '${tempDir.path}/$fileName';

    await _dio.download(
      url,
      tempFilePath,
      cancelToken: cancelToken,
      options: Options(
        receiveTimeout: ApiConfig.downloadReceiveTimeout,
        sendTimeout: ApiConfig.downloadSendTimeout,
      ),
      onReceiveProgress: (received, total) {
        if (total != -1) {
          final progress = received / total;
          onProgress(progress);
        }
      },
    );

    // Save to gallery
    await Gal.putVideo(tempFilePath);
    print('✅ Video saved to gallery');
    
    // Clean up temp file
    await File(tempFilePath).delete();
    
    return 'Gallery';
  }
}